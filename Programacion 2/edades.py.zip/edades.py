SIMBOLO_TERMINAR = 'e'

def printearEdad(edadesAcumuladas, cantEdades):
    print(f"El promedio de edades es {round(edadesAcumuladas/cantEdades, 2)}")


def calcularPromedioEdad():
    ingresoDelUsuario = ""
    edadesAcumuladas = 0
    cantEdades = 0 
    while( ingresoDelUsuario != SIMBOLO_TERMINAR ):
        unaEdad = input(f"Ingrese su edad (>=0) o {SIMBOLO_TERMINAR}:Para terminar: ")
        if (unaEdad == SIMBOLO_TERMINAR):
            if (cantEdades > 0):
                printearEdad(edadesAcumuladas, cantEdades)
            return
        try: 
            unaEdad = int(unaEdad)
        except ValueError:
            print("Error ingrese un numero entero positivo valido! ")
            continue
        cantEdades +=1
        edadesAcumuladas += unaEdad
        printearEdad(edadesAcumuladas, cantEdades)

def main():
    calcularPromedioEdad()

main()